# SqueezeSeg_Ros
This is a ros package that implement the SqueezeSeg
