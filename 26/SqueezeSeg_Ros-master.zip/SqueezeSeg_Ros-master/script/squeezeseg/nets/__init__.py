#-*- coding: utf-8 -*-

from .squeezeSeg import SqueezeSeg
